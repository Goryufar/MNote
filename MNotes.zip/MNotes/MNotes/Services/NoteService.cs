﻿using Microsoft.EntityFrameworkCore;
using MNotes.Data;
using System.Reflection.Metadata;
using TableDependency.SqlClient;
using TableDependency.SqlClient.Base.EventArgs;

namespace MNotes.Services
{
    public class NoteService
    {
        private readonly AppDbContext dbContext = new AppDbContext();
        private readonly SqlTableDependency<noteData> _dependency;
        private readonly string _connectionString;

        public NoteService()
        {
            _connectionString = "Server = (localdb)\\MSSQLLocalDB;Database = myDataBase; Trusted_Connection = True;";
            _dependency = new SqlTableDependency<noteData>(_connectionString, "noteDatas");
            _dependency.OnChanged += Changed;
            _dependency.Start();
        }

        private void Changed(object sender, RecordChangedEventArgs<noteData> e)
        {

        }
        public async Task<List<noteData>> GetAllNotes()
        {
            return await dbContext.noteDatas.AsNoTracking().ToListAsync();
        }
        public async Task AddNote(int parrentId)
        {
            noteData newNote = new noteData();
            newNote.content = "";

            if(parrentId != -1)
                newNote.parrentid = parrentId;
            else
                newNote.parrentid = null;

            dbContext.noteDatas.Add(newNote);
            await dbContext.SaveChangesAsync();
        }
        public async Task changeName(string? nameString, int id)
        {
            var noteToDelete = await dbContext.noteDatas.FindAsync(id);
            if (noteToDelete != null)
            {
                noteToDelete.name = nameString;

            }
            await dbContext.SaveChangesAsync();
        }
        public async Task DeleteNote(int id)
        {
       
            var noteToDelete = await dbContext.noteDatas.FindAsync(id);
            if (noteToDelete != null)
            {
                dbContext.noteDatas.Remove(noteToDelete);

            }
            await dbContext.SaveChangesAsync();
        }
        public async Task UpdateNoteContent(int noteId, string content)
        {
            try
            {
                var note = await dbContext.noteDatas.FindAsync(noteId);

                if (note != null)
                {
                    note.content = content;
                    dbContext.Update(note);
                    dbContext.SaveChanges();
                }
                else
                {
                    Console.WriteLine($"Note with ID {noteId} not found.");
                }
            }
            catch (DbUpdateException ex)
            {
                Console.WriteLine($"Error updating note: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating note: {ex.Message}");
            }
        }

    }
}
