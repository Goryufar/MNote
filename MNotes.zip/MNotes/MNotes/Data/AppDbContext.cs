﻿using Microsoft.EntityFrameworkCore;

namespace MNotes.Data
{
    public class AppDbContext : DbContext
    {
        string _connectionString = "Server = (localdb)\\MSSQLLocalDB;Database = myDataBase; Trusted_Connection = True;";

        public DbSet<noteData> noteDatas { get;set;}
        public DbSet<fileData> fileData { get;set;}
 
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_connectionString);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<noteData>().ToTable(tb => tb.HasTrigger("TriggerName"));
            modelBuilder.Entity<fileData>().ToTable(tb => tb.HasTrigger("TriggerName2"));
            base.OnModelCreating(modelBuilder);
        }
    }
}
