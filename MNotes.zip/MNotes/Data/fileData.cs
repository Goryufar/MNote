﻿namespace MNotes.Data
{
    public class fileData
    {
        public int id { get; set; }
        public string name { get; set; }
        public int contentId { get; set; }
        public int? parentId { get; set; }
        public bool isFavorite { get; set; }


    }
}
